﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Calculator_NEW_UI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        double display = 0;
        double a,b;
        char op;

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            txtDisplay.Text = "0";
        }

        private void btnDot_Click(object sender, RoutedEventArgs e)
        {
            if (!txtDisplay.Text.Contains("."))
            {
                txtDisplay.Text = ".";
                txtDisplay.Text = display.ToString();
            }
        }

        private void btn0_Click(object sender, RoutedEventArgs e)
        {
            var b = sender as Button;
            if(b != null)
            {
                try
                {
                    display = Convert.ToDouble(txtDisplay.Text + b.Content.ToString());
                    if (double.IsFinite(display))
                    {
                        txtDisplay.Text = display.ToString();
                    }
                }
                catch { }
            }
        }

        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            var b = sender as Button;
            if (b != null)
            {
                try
                {
                    display = Convert.ToDouble(txtDisplay.Text + b.Content.ToString());
                    if (double.IsFinite(display))
                    {
                        txtDisplay.Text = display.ToString();
                    }
                }
                catch { }
            }
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            a = Convert.ToDouble(display.ToString());
            op = '+';
            txtDisplay.Text = "0";
        }

        private void btnMinus_Click(object sender, RoutedEventArgs e)
        {
            a = Convert.ToDouble(display.ToString());
            op = '-';
            txtDisplay.Text = "0";
        }

        private void btnDivision_Click(object sender, RoutedEventArgs e)
        {
            a = Convert.ToDouble(display.ToString());
            op = '/';
            txtDisplay.Text = "0";
        }

        private void btnMulti_Click(object sender, RoutedEventArgs e)
        {
            a = Convert.ToDouble(display.ToString());
            op = '*';
            txtDisplay.Text = "0";
        }

        private void btn2_Click(object sender, RoutedEventArgs e)
        {
            var b = sender as Button;
            if (b != null)
            {
                try
                {
                    display = Convert.ToDouble(txtDisplay.Text + b.Content.ToString());
                    if (double.IsFinite(display))
                    {
                        txtDisplay.Text = display.ToString();
                    }
                }catch { }
            }
        }

        private void btn3_Click(object sender, RoutedEventArgs e)
        {
            var b = sender as Button;
            if (b != null)
            {
                try
                {
                    display = Convert.ToDouble(txtDisplay.Text + b.Content.ToString());
                    if (double.IsFinite(display))
                    {
                        txtDisplay.Text = display.ToString();
                    }
                }
                catch { }
            }
        }

        private void btn4_Click(object sender, RoutedEventArgs e)
        {
            var b = sender as Button;
            if (b != null)
            {
                try 
                {
                    display = Convert.ToDouble(txtDisplay.Text + b.Content.ToString());
                    if (double.IsFinite(display))
                    {
                        txtDisplay.Text = display.ToString();
                    }
                } catch { }
            }
        }

        private void btn5_Click(object sender, RoutedEventArgs e)
        {
            var b = sender as Button;
            if (b != null)
            {
                try
                {
                    display = Convert.ToDouble(txtDisplay.Text + b.Content.ToString());
                    if (double.IsFinite(display))
                    {
                        txtDisplay.Text = display.ToString();
                    }
                }
                catch { }
            }
        }

        private void btn6_Click(object sender, RoutedEventArgs e)
        {
            var b = sender as Button;
            if (b != null)
            {
                try
                {
                    display = Convert.ToDouble(txtDisplay.Text + b.Content.ToString());
                    if (double.IsFinite(display))
                    {
                        txtDisplay.Text = display.ToString();
                    }
                }
                catch { }
            }
        }

        private void btn7_Click(object sender, RoutedEventArgs e)
        {
            var b = sender as Button;
            if (b != null)
            {
                try
                {
                    display = Convert.ToDouble(txtDisplay.Text + b.Content.ToString());
                    if (double.IsFinite(display))
                    {
                        txtDisplay.Text = display.ToString();
                    }
                }
                catch { }
            }
        }

        private void btn8_Click(object sender, RoutedEventArgs e)
        {
            var b = sender as Button;
            if (b != null)
            {
                try
                {
                    display = Convert.ToDouble(txtDisplay.Text + b.Content.ToString());
                    if (double.IsFinite(display))
                    {
                        txtDisplay.Text = display.ToString();
                    }
                }
                catch { }
            }
        }

        private void btn9_Click(object sender, RoutedEventArgs e)
        {
            var b = sender as Button;
            if (b != null)
            {
                try
                {
                    display = Convert.ToDouble(txtDisplay.Text + b.Content.ToString());
                    if (double.IsFinite(display))
                    {
                        txtDisplay.Text = display.ToString();
                    }
                }
                catch { }
            }
        }

        private void btnEqual_Click(object sender, RoutedEventArgs e)
        {
            if(op == '+')
            {
                b = Convert.ToDouble(txtDisplay.Text);
                display = a + b;
                txtDisplay.Text = display.ToString();
            }else if(op == '-')
            {
                b = Convert.ToDouble(txtDisplay.Text);
                display = a - b;
                txtDisplay.Text = display.ToString();
            }else if(op == '*')
            {
                b = Convert.ToDouble(txtDisplay.Text);
                display = a * b;
                txtDisplay.Text = display.ToString();
            }else if(op == '/')
            {
                b = Convert.ToDouble(txtDisplay.Text);
                display = a / b;
                txtDisplay.Text = display.ToString();
            }else
            {
                MessageBox.Show("Please choose the correct operator", "warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
